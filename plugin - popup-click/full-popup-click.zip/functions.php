<?php

function pop_create_table() {
    global $wpdb;
    if ($wpdb->get_var("show tables like " . $wpdb->prefix . POP_TABLE) != $wpdb->prefix . POP_TABLE) {
        $sql = "CREATE TABLE IF NOT EXISTS  " . $wpdb->prefix . POP_TABLE . " (
                      campaign_id int(11) NOT NULL AUTO_INCREMENT,
                      campaign_name varchar(255) COLLATE utf8_unicode_ci NOT NULL,
                      campaign_url varchar(255) COLLATE utf8_unicode_ci NOT NULL,
                      website_url text COLLATE utf8_unicode_ci NOT NULL,
                      popup_content_type tinyint(1) NOT NULL DEFAULT '1',
                      popup_url text COLLATE utf8_unicode_ci NOT NULL,
                      popup_html text COLLATE utf8_unicode_ci,
                      popup_dimensions varchar(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT '300X300',
                      popup_iframe_positions varchar(100) NULL,
                      popup_scrolls tinyint(1) NOT NULL DEFAULT '0',
                      popup_delay int(11) NOT NULL DEFAULT '0',
                      popup_animation_type tinyint(1) NOT NULL DEFAULT '0',
                      popup_status tinyint(2) NOT NULL DEFAULT '1',
                      campaign_date int(11) NOT NULL,
                      license_key varchar(200) NULL,
                      mail_service varchar(255) COLLATE utf8_unicode_ci NOT NULL,
                      list_id varchar(50) NULL,
                      redirect_url varchar(255) COLLATE utf8_unicode_ci NOT NULL,
                      PRIMARY KEY (campaign_id)
                    );";

        require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
        dbDelta($sql);
        add_option( 'pop_services', '');
        
    }
}

function pop_license_key($action, $lickey = 0) {
    if ($action == 'get') {
        return get_option('pop_lic_key');
    } elseif ($action == 'add') {
        add_option('pop_lic_key', $lickey);
    } elseif ($action == 'update') {
        update_option('pop_lic_key', $lickey);
    } elseif ($action == 'delete') {
        delete_option('pop_lic_key');
    }
}

function install_product() {
    pop_create_table();
    pop_license_key('add', 0);
}

function uninstall_product() {
    pop_delete_table();
    pop_license_key('delete');
}

function pop_admin_actions() {
    add_menu_page('Pop Click Cash', 'Pop Click Cash', 'administrator', 'popclick', 'layout', plugins_url('popclickcash/images/popicon.ico'));
    add_submenu_page('popclick', 'Pop Click Cash', 'Add New Campaign', 'administrator', 'popclick&loc=addnew', 'layout');
    add_submenu_page('popclick', 'Pop Click Cash', 'Marketing Services', 'administrator', 'popclick&loc=services', 'layout');
    add_submenu_page('popclick', 'Pop Click Cash', 'Add template', 'administrator', 'popclick&loc=templates', 'layout');
}

function layout() {
    include('layout.php');
}

function pop_admin_scripts() {
    wp_deregister_script('jquery');
    wp_register_script('jquery', 'http://ajax.googleapis.com/ajax/libs/jquery/1.7/jquery.min.js');
    wp_enqueue_script('validationengine-en', plugins_url('js/jquery.validationEngine-en.js', __FILE__));
    wp_enqueue_script('validationengine', plugins_url('js/jquery.validationEngine.js', __FILE__));
    wp_enqueue_script('popscript', plugins_url('js/script.js', __FILE__));
    wp_enqueue_script('cufon', plugins_url('js/cufon-yui.js', __FILE__));
    wp_enqueue_script('cufon-font', plugins_url('js/Arial_AMU_400.font.js', __FILE__));

    wp_enqueue_style('popstylesheet', plugins_url('styles/template.css', __FILE__));
    wp_enqueue_style('validationengine-jquery', plugins_url('styles/validationEngine.jquery.css', __FILE__));
    wp_enqueue_style('validationengine-css', plugins_url('styles/styles.css', __FILE__));
}

function pop_delete_table() {
    global $wpdb;
    $wpdb->query("DROP TABLE IF EXISTS " . $wpdb->prefix . POP_TABLE);
    delete_option("pop_services");
    delete_option("pop_tpl_temp_data");
}

function get_campaigns_list($name, $order) {
    global $wpdb;
    $order_stmt = "";
    if ($name && $order) {
        $order_stmt = " ORDER BY `" . $name . "` " . $order;
    }

    $query = $wpdb->get_results("SELECT * FROM " . $wpdb->prefix . POP_TABLE . $order_stmt);
    if ($wpdb->num_rows > 0)
        return $query;
    else
        return array();
}

function check_url($validateValue) {
    global $wpdb;
    $query = $wpdb->get_results("SELECT campaign_id FROM " . $wpdb->prefix . POP_TABLE . " WHERE campaign_url = '" . $validateValue . "'");
    return $wpdb->num_rows;
}

function add_campaign($table_data, $placeholders) {
    global $wpdb;
    $wpdb->insert($wpdb->prefix . POP_TABLE, $table_data, $placeholders);
}

function update_campaign($table_data, $placeholders, $campaign_id) {
    global $wpdb;
    $wpdb->update($wpdb->prefix . POP_TABLE, $table_data, array('campaign_id' => $campaign_id), $placeholders, array('%d'));
}

function delete_campaign($campaign_id) {
    global $wpdb;
    $wpdb->query($wpdb->prepare("DELETE FROM " . $wpdb->prefix . POP_TABLE . " WHERE campaign_id = %d", $campaign_id));
}

function get_campaign($campaign_id) {
    global $wpdb;
    $query = $wpdb->get_results("SELECT * FROM " . $wpdb->prefix . POP_TABLE . " WHERE campaign_id = '" . $campaign_id . "'");
    return $query[0];
}

function disable_enable($campaign_id) {
    global $wpdb;
    $wpdb->query("UPDATE " . $wpdb->prefix . POP_TABLE . " SET popup_status = popup_status * (-1) WHERE campaign_id = '" . $campaign_id . "'");
    $query = $wpdb->get_results("SELECT popup_status FROM " . $wpdb->prefix . POP_TABLE . " WHERE campaign_id = '" . $campaign_id . "'");
    return $query[0];
}

function get_campaign_by_url($campaign_url) {
    global $wpdb;

    $query = $wpdb->get_results("SELECT * FROM " . $wpdb->prefix . POP_TABLE . " WHERE campaign_url = '" . $campaign_url . "'");

    if ($wpdb->num_rows > 0) {
        return $query[0];
    } else {
        return array();
    }
}

function get_template_content($campaign_id) {
    global $wpdb;

    $query = $wpdb->get_results("SELECT popup_html FROM " . $wpdb->prefix . POP_TABLE . " WHERE campaign_id = '" . $campaign_id . "'");

    if ($wpdb->num_rows > 0) {
        return $query[0]->popup_html;
    } else {
        return null;
    }
}

function pop_reminder() {
    $permalink_structure = get_option('permalink_structure');
    if (empty($permalink_structure)) {
        echo '<script type="text/javascript"> jQuery(document).ready(function($){ $(".reminder").show() }); </script>';
    }
}

function check_campaign_id($campaign_id) { 
    global $wpdb;
    $query = $wpdb->get_results("SELECT * FROM " . $wpdb->prefix . POP_TABLE . " WHERE campaign_id = " . $campaign_id);
    if ($wpdb->num_rows > 0) {
        return true;
    } else {
        return false;
    }
}

function get_last_id() {
    global $wpdb;
    $query = $wpdb->get_results("SELECT MAX(campaign_id) FROM " . $wpdb->prefix . POP_TABLE, ARRAY_A);
    return $query[0];
}

function add_teporary_popup($temporary_popup) {
    $query = update_option('pop_temp_teplate', $temporary_popup);
}

function get_temporary_template_content() {
    $temp_content = get_option('pop_temp_teplate');
    
    return $temp_content;
    
}

function pop_execute() {
    global $wpdb;
    $request_uri = $_SERVER['REQUEST_URI'];
    $segments = explode('/', $request_uri);
    if (is_array($segments)) {
        if (isset($segments[1]) && !empty($segments[1])) {
            if ($segments[1] == 'preview') {
                if (!empty($_POST)) {
                    $campaign_data['campaign_name'] = $_POST['campaign_name'];
                    $campaign_data['campaign_name'] = $_POST['short_url'];
                    $campaign_data['website_url'] = $_POST['website_url'];
                    $campaign_data['popup_url'] = $_POST['popup_url'];

                    if (isset($_POST['popup_tpl_html']) && $_POST['popup_tpl_html'] != '') {
                        $campaign_data['popup_html'] = stripcslashes($_POST['popup_tpl_html']);
                        $url = get_last_id();
                        $last_id = $url['MAX(campaign_id)'] + 1;
                        $campaign_data['preview'] = 1;
                        $campaign_data['popup_url'] = 'template/' . $last_id;
                        $temporary_popup = stripcslashes($_POST['popup_tpl_html']);

                        $add_teporary_popup = add_teporary_popup($temporary_popup);
                    } elseif (isset($_POST['popup_html']) && $_POST['popup_html'] != '') {
                        $campaign_data['popup_html'] = $_POST['popup_html'];
                    }

                    $campaign_data['popup_dimensions'] = $_POST['popup_x'] . 'X' . $_POST['popup_y'];
                    $campaign_data['popup_iframe_positions'] = $_POST['iframe_x'] . 'X' . $_POST['iframe_y'];
                    $campaign_data['popup_delay'] = $_POST['popup_delayl'];
                    $campaign_data['popup_animation_type'] = $_POST['popup_animation'];
                    $campaign_data['popup_status'] = 1;
                    $campaign_data['popup_content_type'] = $_POST['content_type'];

                    $campaign_data['popup_scrolls'] = 0;
                    if ($_POST['popup_scrolls'] == 'on')
                        $campaign_data['popup_scrolls'] = 1;

                    header('X-XSS-Protection: 0');
                    include_once('page.php');
                    exit;
                }
            }
            elseif ($segments[1] == 'template') {
                $campaign_id = $segments[2];
                //echo $campaign_id;die;
                if (check_campaign_id($campaign_id) == true) {
                    $template_content = get_template_content($campaign_id);
                } else {
                    $template_content = get_temporary_template_content();
                }
                
                include_once('template.php');
                exit;
            }
            elseif($segments[1] == 'submit'){    
                run_service();
                exit;
            }
            else {
                if (check_url($segments[1]) > 0) {
                    $campaign_data = get_campaign_by_url($segments[1]);
                    
                    header('X-XSS-Protection: 0');
                    
                    if (isset($segments[2]) && !empty($segments[2])) {
                        include_once('page.php');
                        exit;
                    } else {
                        $website_url = $campaign_data->website_url;
                        if(strstr($website_url, 'http://')){
                           $website_url = substr($website_url, 7); 
                        }
                        if(strstr($website_url, 'www')){
                            $website_url = substr($website_url, 4); 
                        }
                        echo '<script type="text/javascript"> window.location.href = "' . get_bloginfo('url') . '/' . $campaign_data->campaign_url . '/' . $website_url . '"; </script>';
                        exit;
                    }
                }
            }
        }
    }
}

function check_lic_key() {
    global $wpdb, $view, $no_menu;
    $no_menu = 0;
    $lic_key = pop_license_key('get');

    if (!$lic_key) {
        $view = 'lickey';
        $no_menu = 1;
    }
}

function buffer_messages($status = null, $msg = '', $error = false) {
    global $msg_buffer;
    $msg_buffer .= '<div ' . ($error ? 'style="color:red"' : '') . '"><strong>' . $msg . '</strong>' . ($status ? '......' . $status : '') . '</div><br />';
}

function register_lic_key($licence_key = null) {
    global $wpdb;
    require_once('simplexml_load_url_curl_helper.php');

    $apiURI = LIC_API_URL . "?operation=db_query&licence_key=" . $licence_key;
    $xml_update = simplexml_load_url_curl($apiURI);

    buffer_messages(null, 'Licence Check');

    // If there are no results... stop the licence is invalid.
    if (count($xml_update->entries->entry) == 0) {
        buffer_messages('Error', 'No Entries Found', 1);
        buffer_messages('Error', 'There was no matching licence found', 1);
        return FALSE;
    }

    // Check to see if they have already registered...
    // This prevents someone using someone else's key.
    $xml_domain = trim((string) $xml_update->entries->entry[0]->domain);

    // Check license key status
    $xml_status = trim((string) $xml_update->entries->entry[0]->status);
    if ($xml_status != 1) {
        buffer_messages(null, 'Licence Disabled');
        return FALSE;
    }

    if ($xml_domain != 'null') {
        buffer_messages('Error', 'Domain is full already', 1);
        return FALSE;
    }

    // If licence keys match...
    $xml_licence = trim((string) $xml_update->entries->entry[0]->licence_key);

    // a quick sanity check to make sure the license key matches...
    if ($xml_licence == $licence_key) {
        buffer_messages('Ok', 'Keys Matched');

        // Build the API query
        $apiURI_update = LIC_API_URL . "?operation=insert_db" .
                "&licence_key=" . $licence_key .
                "&domain=" . get_bloginfo('url') .
                "&username=" .
                "&eMail=" .
                "&password=" .
                "&security_question_1=" .
                "&security_question_2=" .
                "&answer_1=" .
                "&answer_2=" .
                "&status=1" .
                "&security=0";

        buffer_messages(null, 'Update DB URI');

        $xml_update = simplexml_load_url_curl($apiURI_update);

        buffer_messages(null, 'Update DB XML Results');

        $xml_status = (integer) trim($xml_update->success[0]);

        // IF the status was returned as 1
        if ($xml_status == 1) {
            buffer_messages('Ok', 'Everything Worked and We are updated');
            $data = array('license_key' => $licence_key);
            pop_license_key('update', $licence_key);

            return TRUE;
        } else {
            buffer_messages('Error', 'There was a final problem...', 1);
            return FALSE;
        }
    } else {
        buffer_messages('Error', 'Keys did NOT Match.', 1);
        return FALSE;
    }
}

function get_popclick_templates() {
    $templates = array();

    $templates_dir = dirname(__FILE__) . '/templates';
    if (is_dir($templates_dir)) {
        if ($handle = opendir($templates_dir)) {
            while (false !== ($tpl_dir_id = readdir($handle))) {
                if ($tpl_dir_id != "." && $tpl_dir_id != "..") {
                    $tpl_dir = $templates_dir . '/' . $tpl_dir_id;
                    if (is_dir($tpl_dir)) {
                        $templates[] = array(
                            'template_id' => $tpl_dir_id,
                            'screenshot' => plugins_url('popclickcash/templates/' . $tpl_dir_id . '/') . $tpl_dir_id . '.jpg'
                        );
                    }
                }
            }
            closedir($handle);
        }
    }
    return $templates;
}

function get_mail_services() {
    $services = get_option('pop_services');

    $services = unserialize($services);

    return $services;
}

function run_service(){
    global $wpdb;
        
    $referrer = $_SERVER['HTTP_REFERER'];
    $referrer = explode('/', $referrer);
    $campaign_id = $referrer[count($referrer) - 1];
    $result = $wpdb->get_row("SELECT mail_service, list_id, redirect_url FROM " . $wpdb->prefix . POP_TABLE . " WHERE campaign_id = '" . $campaign_id . "'");
    $services = get_option('pop_services');
    $services = unserialize($services);
    $service_email = $services[$result->mail_service]['serviceemail'];
    if($service_email == 'Aweber'){
        run_aweber($result->mail_service, $result->list_id, $result->redirect_url);
    }
    elseif($service_email == 'MailChimp'){
        run_mailChimp($result->mail_service, $result->list_id, $result->redirect_url);
    }
    elseif($service_email == 'GetResponse'){
        run_GetResponse($result->mail_service, $result->list_id, $result->redirect_url);
    }
    elseif($service_email == 'iContact'){
        run_iContact($result->mail_service, $result->list_id, $result->redirect_url);
    }
    
}
function run_iContact($mail_service,$listId,$redirect_url){    
    $subscriber_name = (isset($_POST['name']) ? trim($_POST['name']) : 'Friend');
    $subscriber_email = (isset($_POST['email']) ? trim($_POST['email']) : '');
    require_once('icontact_api/iContactApi.php');    
    $services = get_option('pop_services');
    $services = unserialize($services);

    $appid = $services[$mail_service]["iContactappid"];
    $apiPassword = $services[$mail_service]["iContactpassword"];
    $apiUsername = $services[$mail_service]["iContactusername"];
    iContactApi::getInstance()->setConfig(array(
        'appId'       => $appid, 
        'apiPassword' => $apiPassword, 
        'apiUsername' => $apiUsername
    ));
    $oiContact = iContactApi::getInstance();
    $result_addContact = $oiContact->addContact($subscriber_email,$subscriber_name);
    $contactId = $result_addContact->contactId;
    $result_subscribe = $oiContact->subscribeContactToList($contactId, $listId);
    if($result_subscribe){
        header('Location: ' . $redirect_url);
    } else {
        echo "Unable to subscribe!";
    }
}
function run_GetResponse($mail_service,$campaignId,$redirect_url){
    $subscriber_name = (isset($_POST['name']) ? trim($_POST['name']) : 'Friend');
    $subscriber_email = (isset($_POST['email']) ? trim($_POST['email']) : '');
    
    require_once dirname(__FILE__) . '/getResponse_api/GetResponseAPI.class.php';
    $services = get_option('pop_services');
    $services = unserialize($services);

    $apikey = $services[$mail_service]["api_key"];
    $api = new GetResponse($apikey);
    $result = $api->addContact($campaignId, $subscriber_name, $subscriber_email);
    if($result){
        header('Location: ' . $redirect_url);
    } else {
        echo "Unable to subscribe!";
    }
}
function run_mailChimp($mail_service,$listId,$redirect_url){    
    $subscriber_name = (isset($_POST['name']) ? trim($_POST['name']) : 'Friend');
    $subscriber_email = (isset($_POST['email']) ? trim($_POST['email']) : '');
    
    require_once dirname(__FILE__) . '/mailChimp_api/inc/MCAPI.class.php';
    $services = get_option('pop_services');
    $services = unserialize($services);

    $apikey = $services[$mail_service]["api_key"];
    $api = new MCAPI($apikey);

    $merge_vars = array('FNAME'=>$subscriber_name );
    $retval = $api->listSubscribe( $listId, $subscriber_email, $merge_vars );

    if ($api->errorCode){
            echo "Unable to subscribe!";
    } else {
        header('Location: ' . $redirect_url);
    }
}

function run_aweber($mail_service, $list_id, $redirect_url){    
    $services = get_option('pop_services');
    $services = unserialize($services);
    
    $subscriber_name = (isset($_POST['name']) ? trim($_POST['name']) : 'Friend');
    $subscriber_email = (isset($_POST['email']) ? trim($_POST['email']) : '');
    if (!class_exists('AWeberAPI')) {
        require_once dirname(__FILE__) . '/aweber_api/aweber_api.php';
    }

    if($subscriber_email){
        if (filter_var($subscriber_email, FILTER_VALIDATE_EMAIL)) {
            $app_key = $services[$mail_service]['app_key'];
            $app_secret = $services[$mail_service]['app_secret'];
            $accessToken = $services[$mail_service]['accessToken'];
            $accessTokenSecret = $services[$mail_service]['accessTokenSecret'];

            $aweber = new AWeberAPI($app_key, $app_secret);
            $account = $aweber->getAccount($accessToken, $accessTokenSecret);
            $list = findList($account, $list_id);

            $subscriber = array(
                    'email' => $subscriber_email,
                    'name'  => $subscriber_name
            );

            addSubscriber($account, $subscriber, $list);
            header('Location: ' . $redirect_url);
        }
    }
    exit;
}

function addSubscriber($account, $subscriber, $list) {
    try {
        $listUrl = $list->url;
        $list = $account->loadFromUrl($listUrl);

        $newSubscriber = $list->subscribers->create($subscriber);
    }

    catch(Exception $exc) {
        print $exc;
    }
}

function findList($account, $listName) {
    try {
        $foundLists = $account->lists->find(array('name' => $listName));
        //must pass an associative array to the find method

        return $foundLists[0];
    }

    catch(Exception $exc) {
        print $exc;
    }
}

function check_service_name ($service_name,$serviceemail){    
        $services = get_option('pop_services');
        $services = unserialize($services);
        $counter = 0;
        if(!empty($services)){
            foreach($services as $service => $value){
                if($service_name == $value['servicename'] && $serviceemail == $value['serviceemail']){
                    $counter++;
                }
            }
            return $counter;
        }
        else{
            return $counter;
        }
}

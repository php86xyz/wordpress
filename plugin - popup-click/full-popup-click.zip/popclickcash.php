<?php

/* 
    Plugin Name: Pop Click Cash
    Description: Plugin for creating and managing your campaigns
    Author: popClickAds.
    Author URI: http://popclickads.com
    Version: 0.0.1 
 
 */  


require_once('constants.php');
require_once('functions.php');
require_once('main.php');


register_activation_hook(__FILE__, 'install_product');
register_uninstall_hook(__FILE__, 'uninstall_product');

add_action('admin_menu', 'pop_admin_actions');

add_action('admin_print_styles', 'pop_admin_scripts');

add_action('pre_get_posts', 'pop_execute');

add_action('step_to_popplugin', 'pop_reminder');

add_action('validate_product', 'check_lic_key');

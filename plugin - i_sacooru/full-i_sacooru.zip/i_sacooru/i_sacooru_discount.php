<?php
////////////////////////////////////////////////////////////////////////////////////////////////////
global $wpdb;
$i_msg='';
if(isset($_POST['i_add_discount_foruser']) && $_POST['i_add_discount_foruser']=='1'){
	$email=$_POST['i_email'];
	$i_query=i_add_user_discount($email);
	if($i_query==1){ $i_msg='Email is added.'; }
	if($i_query==2){ $i_msg='Email already added.'; }
}
if(isset($_GET['i_action']) && isset($_GET['info_id']) && $_GET['i_action']=='remove_user_discount' && is_numeric($_GET['info_id'])){
	$i_query= $wpdb->query('DELETE FROM `wp_for_discount` WHERE `id`="'.$_GET['info_id'].'" ');
	if($i_query==1){ $i_msg='Email is removed'; }
}
?>
<style type="text/css">
	.updated.fade { display: none; }
</style>
<div class="wrap i_sacooru">
    <h2>Add user email for discount</h2>
    <br />
    <?php if($i_msg!=''){?>
    <div id="message" class="updated below-h2">
        <p> <?php echo $i_msg; ?> </p>
    </div>
    <?php } ?>
    <form method="post">
    	<label for="i_email_for_discount">Email - </label>
    	<input type="text" name="i_email" value="" id="i_email_for_discount" />
		<input type="hidden" value="1" name="i_add_discount_foruser" />
        <input type="submit" value="Add" class="button button-primary button-large" />
    </form>
    <br />
    <hr />
    <?php
	$i_discount=get_option('i_company_course_discount');
	echo '<h3> Discount is '.$i_discount['discount'].'% for '.$i_discount['days'].' days </h3>';
	print_r($i_company_course_discount);
	?>
    <hr />
    <table class="wp-list-table widefat fixed posts">
    	<thead>
        	<tr>
            	<th>Email</th>
                <th>Date</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
    <?php
		$i_query= $wpdb->get_results('SELECT * FROM `wp_for_discount` ORDER BY `id` ',ARRAY_A);
		if(count($i_query)){
			foreach($i_query as $i_info){
				echo '<tr>';
					echo '<td>'.$i_info['i_email'].'</td>';
					echo '<td>'.$i_info['i_date'].'</td>';
					echo '<td><a href="?page='.$_GET['page'].'&i_action=remove_user_discount&info_id='.$i_info['id'].'" class="remove_user_discount" > Delete </a></td>';
				echo '</tr>';
			}
		}
    ?>
    	</tbody>
    </table>
    <hr />
</div>
<script type="text/javascript">
jQuery(document).ready(function($) {
	$('.remove_user_discount').click(function(){
		if (!confirm("Press a button!")) { return false; }
	});
});
</script>
<?php
?>
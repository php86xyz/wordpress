<?php
	global $icet_path; $t_path=$icet_path;
	echo '<link type="text/css" href="'.$t_path.'style/style.css" rel="stylesheet"/>';
	/*echo '<script type="text/javascript" src="'.$t_path.'js/js.js" > </script>';
	/*************HTML*************/
?>
<fieldset id="sort_area"><legend class="legend"><h2>Your custom email templates</h2></legend>
    <?php
		if($i_googlefont_msg!=''){?>
        <div id="message" class="updated below-h2" style="text-align: left;">
        	<p><?php echo $i_googlefont_msg;?></p>
		</div>
    <?php
		}
	?>
    
    <?php
	$php_words=array(
		'{display_name}','{course_deadline}','{home_url}','{my_business_name}'	
	);
	$icet_templates=array(
		'register_notification'=>'Register notification',
		'subscribe_notification'=>'Subscribe notification',
		'course_ready'=>'Course ready',
		'course_remined'=>'Course remined',
	);
	foreach($icet_templates as $icet_key=>$icet_template){
		$icet_key='icet_'.$icet_key; $icet_info=get_option($icet_key);
		if(!is_array($icet_info)){$icet_info=array('i_email_subject'=>'','i_email_txt'=>'');}
		$i_subject=$icet_info['i_email_subject']; $i_content=stripslashes($icet_info['i_email_txt']);
	?>
    
	<form method="post" action="">		 
		<table class="wp-list-table widefat i_table" cellspacing="0">
        	<thead>
            	<tr>
                	<th><?php echo $icet_template;?> ( Email Template )</th>
                </tr>
            </thead>
			<tbody>
            	<tr>
                	<td> <input type="text" name="i_email_subject" value="<?php echo $i_subject; ?>" placeholder="Email subject" id="title" /> </td>
                </tr>
                <tr>
					<td>
                        <?php
						$r_args = array(
							'textarea_name'=>'i_email_txt', 'textarea_rows'=>15, 'media_buttons' => true,
							//'teeny' => true, 'quicktags' => true,
						);
						wp_editor($i_content, $id = $icet_key,$settings = $r_args);
						?>
                    </td>
				</tr>
			</tbody>
            <tfoot>
            	<tr>
                	<th style="text-align: center;"> 
                    	<?php /*?><input type="submit" value="Save" class="button" /><?php */?>
                        <div class="submit_div">
						<?php submit_button( 'Save content' ); ?>
                        </div>
					</th>
                </tr>
            </tfoot>
		</table>
        <input type="hidden" name="i_icet_action" value="save" />
        <input type="hidden" name="i_email_template" value="<?php echo $icet_key; ?>" />
	</form>
    <div class="i_hr"></div>
    <?php 
	}
	?>
</fieldset>
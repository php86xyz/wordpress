<?php
global $icet_path; $t_path=$icet_path;

if(isset($_POST['i_update_aweber_conf']) && $_POST['i_update_aweber_conf']=='1'){
	update_option('i_sacooru_aweber_conf',array('consumer_key'=>$_POST['i_consumer_key'],'consumer_secret'=>$_POST['i_consumer_secret']));
}

$i_sacooru_aweber_conf=get_option('i_sacooru_aweber_conf');
if(!is_array($i_sacooru_aweber_conf) || !count($i_sacooru_aweber_conf)){
	$i_sacooru_aweber_conf=array('consumer_key'=>'','consumer_secret'=>''); update_option('i_sacooru_aweber_conf',$i_sacooru_aweber_conf);
}
?>
<style type="text/css">
	#i_consumer_key, #i_consumer_secret { width: 500px; }
</style>
<div class="wrap i_sacooru">
    <h2>Aweber App Config</h2>
    <hr />
    <form method="post">
    	<table>
        	<tr>
            	<td><label for="i_consumer_key"> Consumer Key </label></td>
            	<td><input type="text" name="i_consumer_key" value="<?php echo $i_sacooru_aweber_conf['consumer_key'];?>" id="i_consumer_key" /></td>
			</tr>
			<tr>
            	<td><label for="i_consumer_secret"> Consumer Secret </label></td>
            	<td><input type="text" name="i_consumer_secret" value="<?php echo $i_sacooru_aweber_conf['consumer_secret'];?>" id="i_consumer_secret" /></td>
			</tr>
            <tr>
            	<td><input type="hidden" value="1" name="i_update_aweber_conf" /></td>
        		<td style="text-align:center;"><input type="submit" value="Save" class="button button-primary button-large" /></td>
        </table>
    </form>
    <hr />
</div>
var $=jQuery.noConflict();
(function() {
    tinymce.create('tinymce.plugins.Icpt', {
        init : function(ed, url) {			 
            ed.addButton('icpt_shorts', {
                title : 'Add shortcode for email',
                cmd : 'icpt_shorts',
                image : url + '/shortcode_icon.png',
				onclick : function(e) {
					console.log($(e.target));
					$('.icpt_modal').css({'top': e.pageY+10+'px', 'left': (e.pageX-10)+'px'}).toggle(100);
				}
            });			
        },
    });
    // Register plugin
    tinymce.PluginManager.add( 'icpt', tinymce.plugins.Icpt );	
	
	////////////////////////////////////------------
	jQuery(document).ready(function($) {
		$('body').append('<div class="icpt_modal"><ul>\
		<li class="button i_insert_shortcode" data-insert="{home_url}">Home url</li>\
		<li class="button i_insert_shortcode" data-insert="{display_name}">Display Name</li>\
		<li class="button i_insert_shortcode" data-insert="{user_firstname}">User Firstname</li>\
		<li class="button i_insert_shortcode" data-insert="{user_lastname}">User Lastname</li>\
		<li class="button i_insert_shortcode" data-insert="{user_login}">User Login</li>\
		<li class="button i_insert_shortcode" data-insert="{user_pass}">User Password</li>\
		<li class="button i_insert_shortcode" data-insert="{my_business_name}">My Business Name</li>\
		<li class="button i_insert_shortcode" data-insert="{course_deadline}">Course Deadline</li>\
		</ul></div>');
		$('.i_insert_shortcode').click(function (){
			var the_shortcode=$(this).attr('data-insert');
			tinyMCE.activeEditor.execCommand('mceInsertContent', 0, the_shortcode);
			$('.icpt_modal').slideUp(100);
		});
		// inserts the shortcode into the active editor
	});	
})();


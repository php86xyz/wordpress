<?php
/*
Plugin Name: I Sacooru custom options
Plugin URI: 
Description: The custom options and email templates
Author: 
Version: 0.0.1
Author URI: 
*/
?>
<?php
global $icet_plug_dir;
$icet_plug_dir = plugin_dir_path( __FILE__ );
$t_pos=strpos(plugin_basename(__FILE__),'/');
$icet_foldername=substr(plugin_basename(__FILE__), 0,$t_pos);
$icet_path =  plugins_url().'/'.$icet_foldername.'/';
//////////////reg_hook
register_activation_hook(__FILE__, 'gx_icet_install' );
function gx_icet_install() {
	//update_option('i_the_googlefonts',$i_google_fonts);
}
////////
add_action( 'init', 'icpt_configs' );
function icpt_configs() {
	if(isset($_GET['page']) && $_GET['page']=='gx_icet_home'){		
		add_filter( "mce_external_plugins", "icpt_add_buttons" );
		add_filter( 'mce_buttons', 'icpt_register_buttons' );
	}
}
///////////////---------------------
function icpt_add_buttons( $plugin_array ) {
	global $icet_path;
    $plugin_array['icpt'] = $icet_path . 'js/js.js';
    return $plugin_array;
}
function icpt_register_buttons( $buttons ) {
    array_push( $buttons, 'icpt_shorts' ); // dropcap', 'recentposts
    return $buttons;
}
///////////////////////////////////////////////////////////////
add_action('admin_menu', 'gx_icet_admin');
function gx_icet_admin(){
	global $icet_path;
	add_menu_page( 'Sacooru configs', 'Sacooru configs', 'manage_options', 'gx_isacooru_home', 'gx_isacooru_home', $icet_path.'images/icon.png' );
	add_submenu_page( 'gx_isacooru_home', 'Email templates', 'Email templates', 'manage_options', 'gx_icet_home', 'gx_icet_home' );
	add_submenu_page( 'gx_isacooru_home', 'Discount for Email', 'Discount for Email', 'manage_options', 'gx_icet_discount', 'gx_icet_discount' );
	add_submenu_page( 'gx_isacooru_home', 'Aweber Consumer', 'Aweber Consumer', 'manage_options', 'gx_icet_aweber_conf', 'gx_icet_aweber_conf' );
}
function gx_isacooru_home() {
	include 'i_sacooru_home.php';
}
function gx_icet_home() {
	$gx_icet_msg='';
	if( isset($_POST['i_icet_action']) && $_POST['i_icet_action']=='save' ){
		$i_email_txt=$_POST['i_email_txt'];
		$i_email_template=$_POST['i_email_template'];
		$i_email_subject=$_POST['i_email_subject'];
		$icet_info=array('i_email_subject'=>$i_email_subject,'i_email_txt'=>$i_email_txt);
		if(trim($i_email_template)!=''){ update_option($i_email_template,$icet_info); }
	}
	include 'i_cutom_emails_home.php';
}
function gx_icet_discount() {
	include 'i_sacooru_discount.php';
}
function gx_icet_aweber_conf() {
	include 'i_sacooru_aweber_conf.php';
}
///////////////////////////////////////////////////////////////

function i_get_posts_list($args,$value,$name,$id){	
	query_posts($args);
	if( have_posts() ){
		echo '<select name="'.$name.'" id="'.$id.'">';
		while( have_posts() ){the_post();
			echo '<option value="'.get_the_ID().'" ';
			if($value==get_the_ID()){echo 'selected="selected" ';}
			echo '>'.get_the_title().'</option>';
		}  
		echo '</select>';
		wp_reset_query();  
	} else {
	}
}
///////
function icet_get($icet_key,$user_id=0,$course_deadline=''){
	$icet_key='icet_'.$icet_key; $icet_info=get_option($icet_key);
	if(!is_array($icet_info)){$icet_info=array('i_email_subject'=>'','i_email_txt'=>'');}
	
	///////
	if( $user_id>0 ){
		$parent_id=get_user_meta($user_id,'parent_client_id',true);
		$to_user_info=get_userdata( $user_id );
		$my_business_name=get_user_meta( $parent_id, 'wpc_cl_business_name',true);
		$user_email = $to_user_info->user_email;
		
		$email_subject=$icet_info['i_email_subject']; $message=stripslashes($icet_info['i_email_txt']);
		$message=str_replace(
			array(
				'{display_name}',
				'{user_firstname}',
				'{user_lastname}',
				'{course_deadline}',
				'{home_url}',
				'{my_business_name}'
			),
			array(
				$to_user_info->display_name,
				$to_user_info->user_firstname,
				$to_user_info->user_lastname,
				$course_deadline,
				get_home_url(),
				$my_business_name
			),
			$message
		);
		$icet_info['i_email_txt']=addslashes($message);
	}	
	///////	
	return $icet_info;
}
//add_filter('the_content','icet_shortcode');
// ADD NEW COLUMN
function i_sacooru_columns_head($defaults) {
	$defaults['i_free_course'] = 'Free course';
    return $defaults;
}
 
// SHOW THE FEATURED IMAGE
function i_sacooru_columns_content($column_name, $post_ID) {
    if ($column_name == 'i_free_course') {
		if(get_post_meta( $post_ID, 'courese_aweber_subscriber',true)=='1'){ echo 'Aweber Subscribers'; }
    }
}

add_filter('manage_sfwd-courses_posts_columns', 'i_sacooru_columns_head');
add_action('manage_sfwd-courses_posts_custom_column', 'i_sacooru_columns_content', 10, 2);
///
add_action( 'load-post.php', 'i_add_course_metaboxes' );
add_action( 'load-post-new.php', 'i_add_course_metaboxes' );
function i_add_course_metaboxes(){
	add_meta_box( 'learndash-for-subscribers', __( 'Who can see the free course' ), 'i_render_course_metaboxes', 'sfwd-courses', 'side', 'high' );
}
function i_render_course_metaboxes($post){
	$post_id=$post->ID;
?>
    <ul>
    	<li> <label><input type="checkbox" value="1" name="courese_aweber_subscriber" <?php if(get_post_meta( $post_id, 'courese_aweber_subscriber',true)=='1')echo 'checked="checked"'; ?>  /> Aweber Subscribers</label> </li>
    </ul>
<?php
}
add_action( 'save_post', 'i_save_course_metaboxes');
function i_save_course_metaboxes($post_id, $post){
	print_r($post);
	if(isset($_POST['courese_aweber_subscriber'])){
		$courese_aweber_subscriber=$_POST['courese_aweber_subscriber'];		
	} else {
		$courese_aweber_subscriber=0;
	}
	update_post_meta( $post_id, 'courese_aweber_subscriber',  $courese_aweber_subscriber );
}
///// Add user Discount
function i_add_user_discount($email){
	global $wpdb;
	if ( is_email( $email ) ) {
		$i_query= $wpdb->get_results('SELECT * FROM `wp_for_discount` WHERE `i_email`="'.$email.'" ',ARRAY_A);
		if(count($i_query)){ return '2'; }
		
		$i_query= $wpdb->query('INSERT INTO `wp_for_discount` SET `i_email`="'.$email.'", `i_date`="'.date('Y-m-d H:i:s').'" ');
		return $i_query;
	}
}
//
function i_if_has_discount($email){
	global $wpdb;
	$i_email_info= $wpdb->get_row('SELECT * FROM `wp_for_discount` WHERE `i_email`="'.$email.'" ',ARRAY_A);
	
	if(count($i_email_info)){ $i_email_info=$i_email_info['i_date'];
		if(trim($i_email_info)!=''){
			$i_today = date('Y-m-d H:i:s'); $i_today = strtotime($i_today);
			$i_finish = strtotime($i_email_info);
			$timeDiff = abs($i_today - $i_finish); $numberDays = $timeDiff/86400;
			$numberDays = intval($numberDays);
			$i_company_course_discount=get_option('i_company_course_discount');
			if($numberDays<=$i_company_course_discount['days']){return 1;}
		}
	} return 0;
}
function i_ajax_has_discount(){
	if(isset($_POST['action'])){
		echo i_if_has_discount($_POST['bemail']);
	} exit;
} add_action("wp_ajax_nopriv_i_ajax_has_discount", "i_ajax_has_discount"); add_action("wp_ajax_i_ajax_has_discount", "i_ajax_has_discount");
////////////////////////////////////////////////////////////////////////////////////////////////////
?>
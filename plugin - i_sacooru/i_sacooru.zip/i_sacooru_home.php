<?php
global $icet_path; $t_path=$icet_path;
if(isset($_POST['i_update_homepage_videolink']) && $_POST['i_update_homepage_videolink']=='1'){
	update_option('i_homepage_videolink',$_POST['i_homepage_videolink']);
}
if(isset($_POST['i_update_free_course_page']) && $_POST['i_update_free_course_page']=='1'){
	update_option('i_free_course_page',array('post_type'=>$_POST['i_post_type'],'post_id'=>$_POST['i_free_course_page']));
}
if(isset($_POST['i_update_company_course_page']) && $_POST['i_update_company_course_page']=='1'){
	update_option('i_company_course_page',array('post_id'=>$_POST['i_company_course_page']));
}
if(isset($_POST['i_update_company_course_discount']) && $_POST['i_update_company_course_discount']=='1' && is_numeric($_POST['i_company_course_discount']) && is_numeric($_POST['i_company_course_discount_days'])){
	update_option('i_company_course_discount',array('discount'=>$_POST['i_company_course_discount'],'days'=>$_POST['i_company_course_discount_days']));
}
echo '<link type="text/css" href="'.$t_path.'style/style.css" rel="stylesheet"/>';

$i_homepage_videolink=get_option('i_homepage_videolink');

$i_free_course_page=get_option('i_free_course_page');
if(!is_array($i_free_course_page) || !count($i_free_course_page)){ $i_free_course_page=array('post_type'=>'page','post_id'=>'0'); }

$i_company_course_page=get_option('i_company_course_page');
if(!is_array($i_company_course_page) || !count($i_company_course_page)){ $i_company_course_page=array('post_type'=>'page','post_id'=>'0'); }

$i_company_course_discount=get_option('i_company_course_discount');
if(!is_array($i_company_course_discount) || !count($i_company_course_discount)){
	$i_company_course_discount=array('discount'=>'30','days'=>'2'); update_option('i_company_course_discount',$i_company_course_discount);
}
?>
<div class="wrap i_sacooru">
    <h2></h2>
    <div class="logo_banner">
        <img src="<?php echo $t_path.'images/logo.jpg'; ?>" class="i_logo" />
        <img src="<?php echo $t_path.'images/config.png'; ?>" class="i_config_logo" />
    </div>
    
    <form method="post">
        <label for="i_homepage_videolink"> Home video link - </label>
        <?php
        
        ////////
        ?>
        <input type="text" name="i_homepage_videolink" value="<?php echo $i_homepage_videolink;?>" id="i_homepage_videolink" style="width: 420px;" />
        <input type="hidden" value="1" name="i_update_homepage_videolink" />
        <input type="submit" value="Save" class="button button-primary button-large" />
    </form>
    <?php
    $i_post_types=array(
        'page'=>'Pages',
        'sfwd-courses'=>'Courses'
    );
    ?>
    <hr />
    <form method="post">
        <label for="change_post_type">Free course from - </label>
        <select name="i_post_type" id="change_post_type">
        <?php
            foreach($i_post_types as $i_key=>$i_value){
                echo'<option value="'.$i_key.'" ';
                if($i_free_course_page['post_type']==$i_key) echo 'selected="selected" ';
                echo '>'.$i_value.'</option>';
            }
        ?>
        </select>
        <label for="i_free_course_page"> Page link - </label>
        <?php
        $course_post_type=$i_free_course_page['post_type'];
        $i_args=array(
            'post_type'=>$course_post_type,
            'posts_per_page' => -1
        );
        if($course_post_type=='sfwd-courses'){
            $i_args['meta_query']=array(
                array(
                  'key' => 'courese_aweber_subscriber',
                  'compare' => '==',
                  'value' => '1'
                )
            );
        }
        i_get_posts_list($i_args,$i_free_course_page['post_id'],'i_free_course_page','i_free_course_page');
        
        /////////
        echo '<div style="display: none;" id="hidden_selects">';
        foreach($i_post_types as $i_key=>$i_value){
            $course_post_type=$i_key;
            $i_args=array(
                'post_type'=>$course_post_type,
                'posts_per_page' => -1
            );
            if($course_post_type=='sfwd-courses'){
                $i_args['meta_query']=array(
                    array(
                      'key' => 'courese_aweber_subscriber',
                      'compare' => '==',
                      'value' => '1'
                    )
                );
            }
            i_get_posts_list($i_args,'','',$i_key);
        }
        echo '</div>';
        ////////
        ?>
        <input type="hidden" value="1" name="i_update_free_course_page" />
        <input type="submit" value="Save" class="button button-primary button-large" />
    </form>
    <hr />
    <?php
	////////////////////////////////////////////////////////////////////////////////
    ?>
    <form method="post">
        <label for="i_company_course_page"> Company course Page link - </label>
        <?php
        $i_args=array(
            'post_type'=>'sfwd-courses',
            'posts_per_page' => -1
        );
        if($course_post_type=='sfwd-courses'){
            $i_args['meta_query']=array(
                array(
                  'key' => 'courese_aweber_subscriber',
                  'compare' => '!=',
                  'value' => '1'
                )
            );
        }
        i_get_posts_list($i_args,$i_company_course_page['post_id'],'i_company_course_page','i_company_course_page');	
        ////////
        ?>
        <input type="hidden" value="1" name="i_update_company_course_page" />
        <input type="submit" value="Save" class="button button-primary button-large" />
    </form>
    <hr />
    <form method="post">
            <label for="i_company_course_discount">Discount % - </label>
            <input type="text" value="<?php echo $i_company_course_discount['discount']; ?>" name="i_company_course_discount" id="i_company_course_discount" style="margin-right: 10px;" />
            
            <label for="i_company_course_discount_days">Days - </label>
            <input type="text" value="<?php echo $i_company_course_discount['days']; ?>" name="i_company_course_discount_days" id="i_company_course_discount_days" style="margin-right: 10px;" />
		<input type="hidden" value="1" name="i_update_company_course_discount" />
        <input type="submit" value="Save" class="button button-primary button-large" />
    </form>
    <hr />
    <hr />
    <h3>Shortcodes</h3>
    
    <input type="text" value='[int_free_lesson id=" "]' readonly="readonly" class="select_alltxt" /> - Free lesson (change id to free lesson id what you want)
    
    <hr />
</div>
<script type="text/javascript">
jQuery(document).ready(function($) {
    $('#change_post_type').change(function(e) {
        $('#i_free_course_page').html($('#'+$(this).val()).html());
    });
	$('#i_free_course_page').change(function(){ select_hidden_selects($(this).val());});
	function select_hidden_selects(t_value){
		$('#hidden_selects select option').removeAttr('selected');
		$('#hidden_selects select option[value="' + t_value + '"]').attr('selected','selected');
	} select_hidden_selects('<?php echo $i_free_course_page['post_id']; ?>');
	$(".select_alltxt").on('mouseup',function(){ this.select(); });
});
</script>
<?php
?>